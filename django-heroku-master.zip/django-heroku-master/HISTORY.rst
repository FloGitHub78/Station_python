History
=======

v0.2.0
------

- Fix ``SECRET_KEY`` functionality. 
- Change ``settings`` parameter from ``multi_db`` to ``db_colors``.
- Change ``settings`` paramater to not accept more positional arguments.


v0.1.1
------

Minor improvements. 

v0.1.0
------

Initial release.